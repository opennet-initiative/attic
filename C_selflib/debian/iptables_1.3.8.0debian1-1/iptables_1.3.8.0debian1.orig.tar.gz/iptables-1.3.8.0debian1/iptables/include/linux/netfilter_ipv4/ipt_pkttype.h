#ifndef _IPT_PKTTYPE_H
#define _IPT_PKTTYPE_H

struct ipt_pkttype_info {
	int	pkttype;
	int	invert;
};

#endif /*_IPT_PKTTYPE_H*/

#ifndef _IP6T_MARK_H_target
#define _IP6T_MARK_H_target

/* Backwards compatibility for old userspace */
#include <linux/netfilter/xt_MARK.h>

#define ip6t_mark_target_info xt_mark_target_info

#endif /*_IP6T_MARK_H_target*/

#ifndef _IPT_TCPMSS_H
#define _IPT_TCPMSS_H

#include <linux/netfilter/xt_TCPMSS.h>

#define ipt_tcpmss_info		xt_tcpmss_info
#define IPT_TCPMSS_CLAMP_PMTU	XT_TCPMSS_CLAMP_PMTU

#endif /*_IPT_TCPMSS_H*/
